$(document).ready(function(){
	$("#m2 li").click(function(){
		$("#m2 li").css("color","#ff6600");
		$("#m1 li").css("color","black");
		$("#m2 .hang").show();
		$("#m1 .hang").hide();
		$(".hide").hide();
		$(".show").show();
	})
})

$(document).ready(function(){
	$("#m1 li").click(function(){
		$("#m1 li").css("color","#ff6600");
		$("#m2 li").css("color","black");
		$("#m1 .hang").show();
		$("#m2 .hang").hide();
		$(".hide").show();
		$(".show").hide ();
	})
})

$(function(){
	$(".hide2 img").hover(function(){
		$(".hide3 img").show(500);
	}).mouseleave(function(){
		$(".hide3 img").hide();
	})
})

