
$(function(){
	
	//验证账号
	$("#name").blur(function(){
		if($("#name").val()==""){
			$(".p1").html("账号不能为空")
		}else if($("#name").val().length<10){
			$(".p1").html("账号长度要大于10")
		}
		
		
		for(var i=0;i<$("#name").val().length;i++){
			var j=$("#name").val().substring(i,i+1)
			if(j>=0){
				$(".p1").html("用户名不能有数字");
			}
		}
	})
	
	$("#pass").blur(function(){
		if($("#pass").val()==""){
			$(".p3").html("密码不能为空");
		}else if($("#name").val().length<10){
			$(".p1").html("密码长度要大于10")
		}
		
	})
	
})
