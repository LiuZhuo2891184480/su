
//导航栏二级菜单
$(document).ready(function(){
		$("#diyi").hover(function(){
		    $("#sda").show(200);	
		    $("#bai").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia").hover(function(){
		    $(".Top_top_left4").show(200);	
		    $("#bai1").show();
		}).mouseleave(function(){
		$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai1").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia1").hover(function(){
		    $(".Top_top_left5").show(200);	
		    $("#bai2").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai2").hide();
		})
	})

//导航栏右边的二级菜单

$(document).ready(function(){
	$(".Top_left3 .Top_top_left22").hover(function(){
		$(this).css("background","#FFFFFF")
	}).mouseleave(function(){
		$(this).css("background","#f5f5f5")
	})
})

$(document).ready(function(){
		$("#Deng1").hover(function(){
		    $("#Deng").show(200);	
		    $("#bai3").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai3").hide();
		})
	})

$(document).ready(function(){
		$("#Deng2id").hover(function(){
		    $("#Deng2").show(200);	
		    $("#bai4").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai4").hide();
		})
	})

$(document).ready(function(){
		$("#Deng3id").hover(function(){
		    $("#Deng3").show(200);	
		    $("#bai5").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai5").hide();
		})
	})

$(document).ready(function(){
		$("#Deng4id").hover(function(){
		    $("#Deng4").show(200);	
		    $("#bai7").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai7").hide();
		})
	})

$(document).ready(function(){
		$("#Deng5id").hover(function(){
		    $("#Deng5").show(200);	
		    $("#bai10").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai10").hide();
		})
	})


$(function(){
	$(".cia3").click(function(){
		$(".cia3").css("background","#FFFFFF")
		$(".cia2").css("background","#DDDDDD")
		$(".kong").hide();
		$(".kong1").show();
		$(".cai22").hide();
		$(".cai23").show();
	})
})

$(function(){
	$(".cia2").click(function(){
		$(".cia2").css("background","#FFFFFF")
		$(".cia3").css("background","#DDDDDD")
		$(".kong1").hide();
		$(".kong").show();
		$(".cai23").hide();
		$(".cai22").show();
	})
})

$(document).ready(function(){
	$("#zhongj").hide();
	$("#dianji").click(function(){
		$("#zhongj").show();
		$(".gouwu").hide();
	})
})


$(function(){
	$("#shan").click(function(){
		 var flag = confirm("您确定要删除商品吗？")
        if (flag == true) {
            alert("删除成功！");
            $("#se3").remove();
        }else{
            alert("删除失败！")
        }
	
		var a=$(".sets").length;
		if(a==0){
			$("#zhongj").hide();
			$(".gouwu").show();
			
		}else{
			
		}
	})
	
//  $(".eq1").click(function(){
//  	var a=$(".eq2").html();
//  	var an=parseInt(a)+1;
//  	$(".eq2").html(an);
//  	
//  	var zongjia=$("#jiage").html(); //获取商品的总价格
//      var shu=$(".eq2").html();    //获取商品的数量
//      var qian=parseInt(zongjia)*parseInt(shu);
//      $("#zongjia").html(qian);
//  })
//  
//  $(".eq3").click(function(){
//  	var a=$(".eq2").html();
//  	if(a>=1){
//  		var an=parseInt(a)-1;
//  		var zongjia=$("#jiage").html(); //获取商品的总价格
//          var shu=$(".eq2").html();    //获取商品的数量
//          var qian=parseInt(zongjia)*parseInt(shu);
//          $("#zongjia").html(qian);
//  	$(".eq2").html(an);
//  	}else if(a<1){
//  		alert("不能再减了，已经要没有了")
//  	}
//  })
})



$(function(){
	$("#gouwu1").click(function(){
		var a=$("#chaitu").html();
		$("#chaitu img").attr("src","img/and2.gif")
		$("#zhongj").show();
		$(".gouwu").hide();
	})
})



$(function(){
	$(".dianjisai").click(function(){
	alert(1);
	var asd=$(".chgfh").length();
	alert(asd);
   })
})














$(function(){
	$("#quanxze,#quanxze1").click(function(){
		$("[type=checkbox]").prop("checked",this.checked)
	})
})


//$(function(){
//	$(".eq1").click(function(){
//		var asd=$(this).find("li").val();
//		alert(asd);
//	})
//})
